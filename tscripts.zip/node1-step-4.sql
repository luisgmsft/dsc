-- Make a TxLog Backup of the database
BACKUP LOG TestDatabase1 TO DISK = 'c:\TempDSCAssets\TestDatabase1.trn'
GO